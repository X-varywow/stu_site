-- MySQL dump 10.13  Distrib 5.7.34, for Linux (x86_64)
--
-- Host: localhost    Database: blcu_site
-- ------------------------------------------------------
-- Server version	5.7.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `onlyone` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(9) unsigned NOT NULL,
  `lou` tinyint(5) unsigned NOT NULL,
  `content` varchar(150) NOT NULL,
  `user_id` bigint(12) unsigned NOT NULL,
  `edate` timestamp NOT NULL,
  PRIMARY KEY (`onlyone`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (43,59,1,'鼠标悬停于 message 的头像部分可以查看用户微信号',201911581089,'2021-10-14 10:45:04'),(44,59,2,'接上楼，在信息展示的主界面，不是这个界面',201911581089,'2021-10-14 10:45:32'),(46,63,1,'好像不能发表情',999999999999,'2021-10-14 13:11:28');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `likes` (
  `onlyone` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(9) unsigned NOT NULL,
  `name` bigint(12) unsigned NOT NULL,
  PRIMARY KEY (`onlyone`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes`
--

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
INSERT INTO `likes` VALUES (117,59,999999999999),(118,61,999999999999),(119,63,999999999999),(120,59,201911581089);
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `id` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `name` bigint(12) unsigned NOT NULL,
  `title` varchar(60) DEFAULT NULL,
  `content` varchar(420) NOT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `img` varchar(100) DEFAULT NULL,
  `likes` smallint(3) unsigned NOT NULL,
  `edate` timestamp NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (59,201911581089,'','这是一条测试信息。',NULL,NULL,0,'2021-10-14 10:44:15',1),(61,999999999999,'','这是游客身份的测试',NULL,NULL,0,'2021-10-14 11:51:36',1),(62,999999999999,'','出书测试，20，99新',NULL,'../userimg/163421250045392a850b37ea8ae8fc35df52dcbc2.jpg',0,'2021-10-14 11:55:00',2),(63,999999999999,'（无）','太牛啦',NULL,NULL,0,'2021-10-14 13:10:46',1),(64,999999999999,'试试','期待大家都用上的那一天，页面很简洁耶！！！！！期待！！！！',NULL,NULL,0,'2021-10-14 13:26:12',4);
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(4) unsigned NOT NULL COMMENT '唯一ID,对应邀请码ID',
  `name` bigint(12) unsigned NOT NULL,
  `pwd` varchar(16) NOT NULL,
  `register_date` timestamp NOT NULL,
  `nickname` varchar(30) DEFAULT NULL COMMENT '昵称',
  `hphoto` varchar(100) DEFAULT NULL COMMENT '头像',
  `vx` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (0,999999999999,'1','2021-10-14 11:50:52','游客',NULL,'无微信号'),(333,201911580836,'123789','2021-10-14 14:36:32',NULL,NULL,'无微信号'),(9999,201911581089,'111','2021-09-28 16:00:00','将心晴','../hphotos/1633502357yasuo (2).jpg','111');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yqm`
--

DROP TABLE IF EXISTS `yqm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yqm` (
  `id` int(4) NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` bigint(12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yqm`
--

LOCK TABLES `yqm` WRITE;
/*!40000 ALTER TABLE `yqm` DISABLE KEYS */;
INSERT INTO `yqm` VALUES (0,'l52jq',999999999999),(1,'cw3rh',NULL),(2,'4z08w',NULL),(3,'ybc9x',NULL),(4,'7fimh',NULL),(5,'il8ri',NULL),(6,'5z3c9',NULL),(7,'ekzof',NULL),(8,'5vyhi',NULL),(9,'kjyg8',NULL),(10,'jsmhd',NULL),(11,'89z07',NULL),(12,'iiit1',NULL),(13,'g3tzb',NULL),(14,'l860k',NULL),(15,'zlku5',NULL),(16,'x2xg8',NULL),(17,'ebtua',NULL),(18,'myxgz',NULL),(19,'0ooqs',NULL),(20,'2a9bc',NULL),(21,'2e6wy',NULL),(22,'4246j',NULL),(23,'ljr1a',NULL),(24,'nr13k',NULL),(25,'16f4n',NULL),(26,'ectsd',NULL),(27,'2jzvj',NULL),(28,'fg07y',NULL),(29,'pqczp',NULL),(30,'lanpe',NULL),(31,'wv4o5',NULL),(32,'h1b1q',NULL),(33,'c4arg',NULL),(34,'qy4vl',NULL),(35,'1vyaq',NULL),(36,'7fggk',NULL),(37,'24wg6',NULL),(38,'fccy7',NULL),(39,'v1awz',NULL),(40,'ba1ex',NULL),(41,'jdz4r',NULL),(42,'79nxw',NULL),(43,'z4p6u',NULL),(44,'pnuuc',NULL),(45,'4wm8f',NULL),(46,'n7lnt',NULL),(47,'9nhh0',NULL),(48,'0qjoe',NULL),(49,'hfdkg',NULL),(50,'4cwz4',NULL),(51,'0wkn9',NULL),(52,'w1s10',NULL),(53,'kwr2y',NULL),(54,'s8bxf',NULL),(55,'07ndr',NULL),(56,'2h990',NULL),(57,'2dmey',NULL),(58,'k8awr',NULL),(59,'umo8g',NULL),(60,'fs5em',NULL),(61,'ddndp',NULL),(62,'gpk30',NULL),(63,'dykee',NULL),(64,'idzgj',NULL),(65,'ushnl',NULL),(66,'wtihd',NULL),(67,'7ib2j',NULL),(68,'ep4kn',NULL),(69,'i6dtf',NULL),(70,'3yqu7',NULL),(71,'8792c',NULL),(72,'f4hwc',NULL),(73,'zdyd8',NULL),(74,'jw9hj',NULL),(75,'fwmaz',NULL),(76,'jo8mx',NULL),(77,'a4vsy',NULL),(78,'64t5d',NULL),(79,'znvql',NULL),(80,'t81ra',NULL),(81,'71rez',NULL),(82,'xevek',NULL),(83,'cg804',NULL),(84,'bjap4',NULL),(85,'4mfl5',NULL),(86,'l2k4h',NULL),(87,'h5320',NULL),(88,'tsjhp',NULL),(89,'ebnuc',NULL),(90,'czaf8',NULL),(91,'brgps',NULL),(92,'jl84y',NULL),(93,'7uris',NULL),(94,'dbyij',NULL),(95,'jrlbl',NULL),(96,'ie8c9',NULL),(97,'sylz2',NULL),(98,'lt7hi',NULL),(99,'icm51',NULL),(100,'czwqe',NULL),(101,'597g7',NULL),(102,'3jehv',NULL),(103,'gb4ls',NULL),(104,'p404e',NULL),(105,'584bi',NULL),(106,'x8ch8',NULL),(107,'q1cz8',NULL),(108,'mtj7b',NULL),(109,'8il01',NULL),(110,'vk1ui',NULL),(111,'006dq',NULL),(112,'spcyj',NULL),(113,'t8kkh',NULL),(114,'3w55e',NULL),(115,'cjbv2',NULL),(116,'o4sv0',NULL),(117,'hdo2n',NULL),(118,'rbgyf',NULL),(119,'uhr0a',NULL),(120,'abdhj',NULL),(121,'bhpdi',NULL),(122,'cmhvw',NULL),(123,'6yoss',NULL),(124,'s61yw',NULL),(125,'ljqzv',NULL),(126,'f53os',NULL),(127,'cd8d9',NULL),(128,'9oitu',NULL),(129,'4d2y9',NULL),(130,'v3es3',NULL),(131,'5iypj',NULL),(132,'23dyf',NULL),(133,'242k6',NULL),(134,'bvy76',NULL),(135,'gv4hl',NULL),(136,'ohqrt',NULL),(137,'qk7wf',NULL),(138,'fg60z',NULL),(139,'f8tsf',NULL),(140,'q38kw',NULL),(141,'adcoi',NULL),(142,'io17x',NULL),(143,'w5dbc',NULL),(144,'qgbyk',NULL),(145,'65zu5',NULL),(146,'4so5j',NULL),(147,'qxfz1',NULL),(148,'0mnjv',NULL),(149,'u2wb6',NULL),(150,'77tjj',NULL),(151,'bci3f',NULL),(152,'s1s2n',NULL),(153,'uf638',NULL),(154,'b4u79',NULL),(155,'xn0xq',NULL),(156,'ulc6t',NULL),(157,'fh8h5',NULL),(158,'w9yxm',NULL),(159,'eqfzk',NULL),(160,'a4lvr',NULL),(161,'39631',NULL),(162,'d6009',NULL),(163,'bmflp',NULL),(164,'gk2dn',NULL),(165,'ydqmt',NULL),(166,'t0v3z',NULL),(167,'sprc2',NULL),(168,'uojqz',NULL),(169,'tfj2g',NULL),(170,'qmz5i',NULL),(171,'wg823',NULL),(172,'d8qkz',NULL),(173,'hq1ps',NULL),(174,'5a59k',NULL),(175,'ys40b',NULL),(176,'wb0dz',NULL),(177,'d833w',NULL),(178,'4t8mo',NULL),(179,'5a7wn',NULL),(180,'t04oq',NULL),(181,'0cmgb',NULL),(182,'1l62a',NULL),(183,'wqgvl',NULL),(184,'3t5ab',NULL),(185,'9u2ye',NULL),(186,'4a707',NULL),(187,'rh5nl',NULL),(188,'kyx6i',NULL),(189,'qq8rs',NULL),(190,'itp1b',NULL),(191,'1hw36',NULL),(192,'wony0',NULL),(193,'3k7b6',NULL),(194,'60q16',NULL),(195,'st0al',NULL),(196,'adlg0',NULL),(197,'fksov',NULL),(198,'mztnt',NULL),(199,'qfrzn',NULL),(200,'3h1jr',NULL),(201,'zvi8k',NULL),(202,'x75rh',NULL),(203,'kmz2z',NULL),(204,'jls3f',NULL),(205,'w2uh9',NULL),(206,'7w9wa',NULL),(207,'5cgj6',NULL),(208,'nriqe',NULL),(209,'kp9d5',NULL),(210,'xaouo',NULL),(211,'fh7g5',NULL),(212,'fyy7v',NULL),(213,'suj0o',NULL),(214,'ogoof',NULL),(215,'xxdpy',NULL),(216,'4u4t0',NULL),(217,'6yscc',NULL),(218,'mm366',NULL),(219,'a9olu',NULL),(220,'m20ng',NULL),(221,'huukt',NULL),(222,'bztvh',NULL),(223,'tnmtd',NULL),(224,'dyko4',NULL),(225,'g3oy4',NULL),(226,'bhx1q',NULL),(227,'dgafc',NULL),(228,'4pup7',NULL),(229,'ru18h',NULL),(230,'tijtj',NULL),(231,'r6ylq',NULL),(232,'y7s7l',NULL),(233,'vqvrp',NULL),(234,'34tvj',NULL),(235,'bet5w',NULL),(236,'cljkm',NULL),(237,'0paky',NULL),(238,'xcyat',NULL),(239,'jfqvb',NULL),(240,'cdsih',NULL),(241,'cpd8b',NULL),(242,'3u5su',NULL),(243,'c02kn',NULL),(244,'80b6v',NULL),(245,'j4hgq',NULL),(246,'zn6cf',NULL),(247,'650gy',NULL),(248,'9lslx',NULL),(249,'p51hj',NULL),(250,'hc0mr',NULL),(251,'b2xer',NULL),(252,'xwpiq',NULL),(253,'f5rw5',NULL),(254,'9pwip',NULL),(255,'euct8',NULL),(256,'gzl53',NULL),(257,'dq9pv',NULL),(258,'8yr7l',NULL),(259,'7oidd',NULL),(260,'u08yi',NULL),(261,'to1nl',NULL),(262,'4j0hk',NULL),(263,'umqa6',NULL),(264,'yxn8j',NULL),(265,'rtvx8',NULL),(266,'uetqv',NULL),(267,'192bb',NULL),(268,'gioxz',NULL),(269,'34neq',NULL),(270,'b6vj1',NULL),(271,'ge5s1',NULL),(272,'x0sqt',NULL),(273,'o0zxq',NULL),(274,'as80f',NULL),(275,'9kywe',NULL),(276,'30zuk',NULL),(277,'pf9w2',NULL),(278,'d7sab',NULL),(279,'9biws',NULL),(280,'lqfuu',NULL),(281,'tmu19',NULL),(282,'kcqg1',NULL),(283,'g2q5t',NULL),(284,'h6a17',NULL),(285,'r8cxq',NULL),(286,'8so7d',NULL),(287,'oq5d5',NULL),(288,'ngsme',NULL),(289,'yxbpx',NULL),(290,'ma2lc',NULL),(291,'12k2n',NULL),(292,'iyyrf',NULL),(293,'f1z9w',NULL),(294,'v37je',NULL),(295,'4s0hn',NULL),(296,'0u30i',NULL),(297,'c9una',NULL),(298,'ud6ei',NULL),(299,'yx665',NULL),(300,'k3uxj',NULL),(301,'hibv3',NULL),(302,'e5eze',NULL),(303,'5h9zu',NULL),(304,'kg9dh',NULL),(305,'arqpd',NULL),(306,'23auj',NULL),(307,'3jthj',NULL),(308,'ejfse',NULL),(309,'a11t2',NULL),(310,'5o1zb',NULL),(311,'d4eqj',NULL),(312,'hk9ez',NULL),(313,'b7kdm',NULL),(314,'9mymx',NULL),(315,'noakh',NULL),(316,'hf0zg',NULL),(317,'5hs8t',NULL),(318,'v94zm',NULL),(319,'17vwd',NULL),(320,'3waet',NULL),(321,'iyr6l',NULL),(322,'3t8vl',NULL),(323,'avh8k',NULL),(324,'e8c70',NULL),(325,'rgcio',NULL),(326,'wip6s',NULL),(327,'jmnlk',NULL),(328,'erikq',NULL),(329,'6sgd0',NULL),(330,'2w8dx',NULL),(331,'5uzvx',NULL),(332,'x42zz',NULL),(333,'jm4ih',201911580836),(334,'trc8u',NULL),(335,'jv25v',NULL),(336,'3adc3',NULL),(337,'hby9m',NULL),(338,'ijmhr',NULL),(339,'p1ir0',NULL),(340,'1chrl',NULL),(341,'7nw6d',NULL),(342,'wr4kz',NULL),(343,'p0e79',NULL),(344,'utsoj',NULL),(345,'k6vza',NULL),(346,'7jy4u',NULL),(347,'6yy6q',NULL),(348,'2t6rm',NULL),(349,'omv8a',NULL),(350,'ucunf',NULL),(351,'utwif',NULL),(352,'idx5q',NULL),(353,'t8zxu',NULL),(354,'omilo',NULL),(355,'b6gn9',NULL),(356,'glc4c',NULL),(357,'g4bha',NULL),(358,'pgvea',NULL),(359,'ksfoj',NULL),(360,'5imuf',NULL),(361,'1uhau',NULL),(362,'l7gg3',NULL),(363,'hf2cl',NULL),(364,'gx99l',NULL),(365,'levsz',NULL),(366,'azrce',NULL),(367,'0ypwh',NULL),(368,'07l50',NULL),(369,'psrmm',NULL),(370,'guju4',NULL),(371,'ojn9r',NULL),(372,'or7bc',NULL),(373,'14lt3',NULL),(374,'7xhur',NULL),(375,'jt2oa',NULL),(376,'6byb9',NULL),(377,'9ezvv',NULL),(378,'wubbo',NULL),(379,'3s557',NULL),(380,'tvup6',NULL),(381,'zib20',NULL),(382,'u591j',NULL),(383,'rjxqp',NULL),(384,'qzrpp',NULL),(385,'x1kbe',NULL),(386,'nkg43',NULL),(387,'6ysjq',NULL),(388,'9zy00',NULL),(389,'zybzm',NULL),(390,'xmynu',NULL),(391,'c2lwp',NULL),(392,'kv0cs',NULL),(393,'w3c8o',NULL),(394,'9leff',NULL),(395,'j52q6',NULL),(396,'gozi4',NULL),(397,'b8zo7',NULL),(398,'90tt7',NULL),(399,'slvlk',NULL),(400,'4nya0',NULL),(401,'zhvfv',NULL),(402,'8bu5g',NULL),(403,'os37g',NULL),(404,'wby96',NULL),(405,'wfwgx',NULL),(406,'6ds1d',NULL),(407,'jv9rz',NULL),(408,'htfk8',NULL),(409,'mq1gx',NULL),(410,'pzbze',NULL),(411,'n4pyo',NULL),(412,'ycctp',NULL),(413,'d1zsa',NULL),(414,'ypen6',NULL),(415,'cm94l',NULL),(416,'vb08z',NULL),(417,'04xn8',NULL),(418,'lefda',NULL),(419,'71kqk',NULL),(420,'p4sbs',NULL),(421,'22r4l',NULL),(422,'k8vvb',NULL),(423,'yngzw',NULL),(424,'bqxgu',NULL),(425,'5mdf5',NULL),(426,'xrer9',NULL),(427,'ro13f',NULL),(428,'mp0qu',NULL),(429,'3bmkw',NULL),(430,'dxbv5',NULL),(431,'yiz7s',NULL),(432,'xycoe',NULL),(433,'nrlyy',NULL),(434,'02p6w',NULL),(435,'zs11i',NULL),(436,'7ro1d',NULL),(437,'fxqim',NULL),(438,'qhjaq',NULL),(439,'dpkv1',NULL),(440,'bjcpi',NULL),(441,'7r0ir',NULL),(442,'hbvxn',NULL),(443,'b6pu4',NULL),(444,'dd2s2',NULL),(445,'tuot1',NULL),(446,'4abxs',NULL),(447,'j3592',NULL),(448,'2mpz5',NULL),(449,'fmwv4',NULL),(450,'vwx1c',NULL),(451,'h2l2j',NULL),(452,'p8j9v',NULL),(453,'zxz0q',NULL),(454,'umcc3',NULL),(455,'3cwjq',NULL),(456,'vb5xb',NULL),(457,'7ihsk',NULL),(458,'cmy3a',NULL),(459,'lfbqq',NULL),(460,'4k8gx',NULL),(461,'111zu',NULL),(462,'a8ucr',NULL),(463,'sq62b',NULL),(464,'va4ua',NULL),(465,'839y7',NULL),(466,'mtmct',NULL),(467,'7pzgj',NULL),(468,'00tq8',NULL),(469,'8turi',NULL),(470,'vwj9k',NULL),(471,'idmr6',NULL),(472,'pzqwo',NULL),(473,'mkuu8',NULL),(474,'9w7f9',NULL),(475,'pnsm0',NULL),(476,'nyera',NULL),(477,'9m2ut',NULL),(478,'8jwxl',NULL),(479,'hvj6a',NULL),(480,'d3sjj',NULL),(481,'518ok',NULL),(482,'wt8fh',NULL),(483,'aapd9',NULL),(484,'hrdqq',NULL),(485,'3uwot',NULL),(486,'25bac',NULL),(487,'z43ut',NULL),(488,'8bcvb',NULL),(489,'j1626',NULL),(490,'23vhx',NULL),(491,'scvlp',NULL),(492,'9milx',NULL),(493,'gstlu',NULL),(494,'qtvp6',NULL),(495,'w8wh9',NULL),(496,'84niz',NULL),(497,'ha6x1',NULL),(498,'qhjmq',NULL),(499,'jv93x',NULL),(500,'czs7p',NULL),(501,'s0r8u',NULL),(502,'dg8ih',NULL),(503,'jc3fl',NULL),(504,'lk6a0',NULL),(505,'9rf76',NULL),(506,'51tno',NULL),(507,'2xs8g',NULL),(508,'yi9ce',NULL),(509,'zt50m',NULL),(510,'ei7as',NULL),(511,'cnvmk',NULL),(512,'2wh4g',NULL),(513,'ndzp3',NULL),(514,'gx5kx',NULL),(515,'eb20o',NULL),(516,'p0o8n',NULL),(517,'7h4bb',NULL),(518,'u3xqs',NULL),(519,'kw8zk',NULL),(520,'wkblr',NULL),(521,'16tto',NULL),(522,'2kwy5',NULL),(523,'47uqg',NULL),(524,'en88p',NULL),(525,'nrvvg',NULL),(526,'mqifn',NULL),(527,'0ypag',NULL),(528,'c4pmk',NULL),(529,'0lyn0',NULL),(530,'f9zhk',NULL),(531,'seajg',NULL),(532,'wck5g',NULL),(533,'96zm6',NULL),(534,'1ces0',NULL),(535,'bxjpo',NULL),(536,'6s692',NULL),(537,'58bdk',NULL),(538,'kc344',NULL),(539,'w4cgs',NULL),(540,'ntw56',NULL),(541,'zgs6w',NULL),(542,'yx9mh',NULL),(543,'yzmif',NULL),(544,'ngzzz',NULL),(545,'kaxcp',NULL),(546,'guzeg',NULL),(547,'hdvbn',NULL),(548,'xggvx',NULL),(549,'qd0cf',NULL),(550,'804or',NULL),(551,'f25y0',NULL),(552,'l0x4l',NULL),(553,'kduk9',NULL),(554,'54r9z',NULL),(555,'gd0lo',NULL),(556,'ekxor',NULL),(557,'i89hv',NULL),(558,'s2684',NULL),(559,'8l7eh',NULL),(560,'ukups',NULL),(561,'686j7',NULL),(562,'3dnnv',NULL),(563,'v1v81',NULL),(564,'bivuq',NULL),(565,'xmfrh',NULL),(566,'2zg06',NULL),(567,'0z3nn',NULL),(568,'37mfi',NULL),(569,'o0z2a',NULL),(570,'4qj97',NULL),(571,'04ol6',NULL),(572,'9nvaq',NULL),(573,'82gmf',NULL),(574,'jgdwl',NULL),(575,'qqxft',NULL),(576,'31avl',NULL),(577,'2ixul',NULL),(578,'bevk9',NULL),(579,'6ksq3',NULL),(580,'s4sqt',NULL),(581,'3pcg4',NULL),(582,'md9eo',NULL),(583,'i7snw',NULL),(584,'dr6ci',NULL),(585,'rcsxl',NULL),(586,'cmg04',NULL),(587,'jlie4',NULL),(588,'vb3oa',NULL),(589,'ynkdf',NULL),(590,'q23qa',NULL),(591,'nbga5',NULL),(592,'p0q4f',NULL),(593,'rytjl',NULL),(594,'z61x6',NULL),(595,'2ryhw',NULL),(596,'yv436',NULL),(597,'p7qs5',NULL),(598,'eisg1',NULL),(599,'bvj31',NULL),(600,'xwsyp',NULL),(601,'seqeq',NULL),(602,'krcqv',NULL),(603,'jk4k7',NULL),(604,'4cssb',NULL),(605,'85zfl',NULL),(606,'htcqh',NULL),(607,'nw10s',NULL),(608,'9s8ne',NULL),(609,'oonrt',NULL),(610,'4ryad',NULL),(611,'n2f8e',NULL),(612,'wlynp',NULL),(613,'3ocb6',NULL),(614,'lxr2c',NULL),(615,'0n5e2',NULL),(616,'5na7x',NULL),(617,'dvjnz',NULL),(618,'xjkwh',NULL),(619,'q3r8r',NULL),(620,'hqzlo',NULL),(621,'fe4tf',NULL),(622,'eiw32',NULL),(623,'wrn42',NULL),(624,'cl0wx',NULL),(625,'u2ur7',NULL),(626,'ybpvy',NULL),(627,'wh2ad',NULL),(628,'smya6',NULL),(629,'o7w9c',NULL),(630,'tqrij',NULL),(631,'hkfm8',NULL),(632,'4lx22',NULL),(633,'td4xg',NULL),(634,'7r8ws',NULL),(635,'j69j2',NULL),(636,'tfuxo',NULL),(637,'faqez',NULL),(638,'d1lf1',NULL),(639,'w5dgb',NULL),(640,'qzzeh',NULL),(641,'coatz',NULL),(642,'9qbim',NULL),(643,'coh9h',NULL),(644,'73v41',NULL),(645,'4qobx',NULL),(646,'r7oft',NULL),(647,'mh254',NULL),(648,'9wbiv',NULL),(649,'vznhb',NULL),(650,'ozkzs',NULL),(651,'n8tbj',NULL),(652,'f2wwd',NULL),(653,'t7lnj',NULL),(654,'r2w0p',NULL),(655,'11vxq',NULL),(656,'avnu7',NULL),(657,'1my9p',NULL),(658,'koit8',NULL),(659,'6r10f',NULL),(660,'fbce2',NULL),(661,'16myl',NULL),(662,'ina36',NULL),(663,'ogred',NULL),(664,'5pvza',NULL),(665,'is2rn',NULL),(666,'rau16',NULL),(667,'0pmyn',NULL),(668,'a1q5l',NULL),(669,'29y3a',NULL),(670,'gwagk',NULL),(671,'t5vux',NULL),(672,'jb6ib',NULL),(673,'8024m',NULL),(674,'75s9v',NULL),(675,'muddn',NULL),(676,'qzp4h',NULL),(677,'a5sr5',NULL),(678,'u22js',NULL),(679,'0m85c',NULL),(680,'zblz0',NULL),(681,'0jez4',NULL),(682,'1stma',NULL),(683,'pean9',NULL),(684,'w29gw',NULL),(685,'dke01',NULL),(686,'0x1bu',NULL),(687,'8enr9',NULL),(688,'s37fi',NULL),(689,'y0xfr',NULL),(690,'qfite',NULL),(691,'zrrnn',NULL),(692,'j6ivg',NULL),(693,'pg789',NULL),(694,'enxb9',NULL),(695,'frks4',NULL),(696,'cznzc',NULL),(697,'a1x0p',NULL),(698,'bfnia',NULL),(699,'el6li',NULL),(700,'lk1ej',NULL),(701,'b8oc0',NULL),(702,'0z6w2',NULL),(703,'tr6wk',NULL),(704,'6t7p6',NULL),(705,'mnq6e',NULL),(706,'a04xs',NULL),(707,'zw58t',NULL),(708,'1f1ug',NULL),(709,'kv8it',NULL),(710,'pr1ja',NULL),(711,'dm6yq',NULL),(712,'l4hcs',NULL),(713,'khj0l',NULL),(714,'gnbsg',NULL),(715,'j6zwv',NULL),(716,'fcits',NULL),(717,'7vfqc',NULL),(718,'znskb',NULL),(719,'rxf94',NULL),(720,'3gzcm',NULL),(721,'x43pm',NULL),(722,'h4gxr',NULL),(723,'z1h48',NULL),(724,'oifi0',NULL),(725,'zg3fd',NULL),(726,'nci5k',NULL),(727,'x5458',NULL),(728,'n09u9',NULL),(729,'gkyyx',NULL),(730,'pgies',NULL),(731,'xb7xq',NULL),(732,'fg86z',NULL),(733,'x532c',NULL),(734,'7u218',NULL),(735,'gjwrx',NULL),(736,'hhtcz',NULL),(737,'t5g3o',NULL),(738,'zl8hk',NULL),(739,'lnriu',NULL),(740,'ecthz',NULL),(741,'ulvkt',NULL),(742,'2h8y5',NULL),(743,'g2t1t',NULL),(744,'ivluh',NULL),(745,'2piv1',NULL),(746,'k3q53',NULL),(747,'8havs',NULL),(748,'vs545',NULL),(749,'za3vl',NULL),(750,'ml5sn',NULL),(751,'loxpo',NULL),(752,'fxv0q',NULL),(753,'k5mlw',NULL),(754,'xow2n',NULL),(755,'hx0ct',NULL),(756,'saiyt',NULL),(757,'es4zr',NULL),(758,'6e35w',NULL),(759,'4wpnu',NULL),(760,'aw3b0',NULL),(761,'mm6ga',NULL),(762,'daia7',NULL),(763,'38xb3',NULL),(764,'huo68',NULL),(765,'8384j',NULL),(766,'lvy6q',NULL),(767,'ixicv',NULL),(768,'yt6xb',NULL),(769,'xpvsq',NULL),(770,'54zfc',NULL),(771,'vy57a',NULL),(772,'bnpsx',NULL),(773,'p7piz',NULL),(774,'e92uw',NULL),(775,'m801o',NULL),(776,'u654g',NULL),(777,'ns9rz',NULL),(778,'f8mgr',NULL),(779,'vadoc',NULL),(780,'oihv2',NULL),(781,'o6o2f',NULL),(782,'42att',NULL),(783,'p9czi',NULL),(784,'o08f5',NULL),(785,'ereas',NULL),(786,'0xbqz',NULL),(787,'1fsk7',NULL),(788,'w2bun',NULL),(789,'hb9sf',NULL),(790,'ndnun',NULL),(791,'q3k02',NULL),(792,'64rda',NULL),(793,'y94ne',NULL),(794,'9eafr',NULL),(795,'kd8gs',NULL),(796,'42yrj',NULL),(797,'j8cnn',NULL),(798,'nftc3',NULL),(799,'2ujvn',NULL),(800,'7g72q',NULL),(801,'twj38',NULL),(802,'kf2fc',NULL),(803,'fehr0',NULL),(804,'ny8lr',NULL),(805,'n8jd6',NULL),(806,'aldg8',NULL),(807,'g90ts',NULL),(808,'m7i6e',NULL),(809,'9krd7',NULL),(810,'xpio7',NULL),(811,'gvak4',NULL),(812,'ozyt7',NULL),(813,'frwkg',NULL),(814,'rgvl4',NULL),(815,'qnc65',NULL),(816,'m2f9j',NULL),(817,'zgsbu',NULL),(818,'07r5b',NULL),(819,'51amf',NULL),(820,'cvilp',NULL),(821,'n3hrs',NULL),(822,'ic42p',NULL),(823,'s6ulj',NULL),(824,'rgoln',NULL),(825,'vp61c',NULL),(826,'at7mr',NULL),(827,'6p30q',NULL),(828,'jnx4p',NULL),(829,'5hl4y',NULL),(830,'w834j',NULL),(831,'ed7tz',NULL),(832,'ns1gr',NULL),(833,'o2cs6',NULL),(834,'sdnha',NULL),(835,'z3ld4',NULL),(836,'ap6cg',NULL),(837,'w77ll',NULL),(838,'nrkx7',NULL),(839,'flel3',NULL),(840,'ymv0f',NULL),(841,'kj0ng',NULL),(842,'ja9xs',NULL),(843,'jsz6h',NULL),(844,'cqhob',NULL),(845,'8vj91',NULL),(846,'v4v55',NULL),(847,'dzugv',NULL),(848,'8ujrz',NULL),(849,'b0mxt',NULL),(850,'ccn94',NULL),(851,'u43iq',NULL),(852,'b32bz',NULL),(853,'p8yl3',NULL),(854,'0oift',NULL),(855,'ko0te',NULL),(856,'cswy0',NULL),(857,'h2joe',NULL),(858,'eqktu',NULL),(859,'ufups',NULL),(860,'poazd',NULL),(861,'jhg18',NULL),(862,'khfc9',NULL),(863,'h90y7',NULL),(864,'1jjeo',NULL),(865,'k03fh',NULL),(866,'on9oa',NULL),(867,'ggdkz',NULL),(868,'4ev6y',NULL),(869,'hwodf',NULL),(870,'qsm3r',NULL),(871,'xy82q',NULL),(872,'yverm',NULL),(873,'u6ebq',NULL),(874,'t3yvw',NULL),(875,'a7fxx',NULL),(876,'ri6w2',NULL),(877,'e7p23',NULL),(878,'nxkge',NULL),(879,'ouuht',NULL),(880,'ob5u1',NULL),(881,'2czew',NULL),(882,'tcqpt',NULL),(883,'vqbvw',NULL),(884,'jhlnp',NULL),(885,'ws25n',NULL),(886,'p8fed',NULL),(887,'63f2u',NULL),(888,'5pid1',NULL),(889,'hpwjg',NULL),(890,'yh9zf',NULL),(891,'k7bqn',NULL),(892,'hej5y',NULL),(893,'ivyfk',NULL),(894,'0potk',NULL),(895,'789fg',NULL),(896,'7d7t6',NULL),(897,'ewozr',NULL),(898,'qxlvv',NULL),(899,'klfdf',NULL),(900,'o8bcu',NULL),(901,'ooatp',NULL),(902,'xbumn',NULL),(903,'yek60',NULL),(904,'al4xv',NULL),(905,'r42pa',NULL),(906,'g8rei',NULL),(907,'e5ert',NULL),(908,'rotbx',NULL),(909,'x89lb',NULL),(910,'d04gr',NULL),(911,'xtg8t',NULL),(912,'pgu0a',NULL),(913,'lkjjh',NULL),(914,'pkh02',NULL),(915,'2c31r',NULL),(916,'5i654',NULL),(917,'s63jj',NULL),(918,'g2ik7',NULL),(919,'tyt1t',NULL),(920,'qrfso',NULL),(921,'u8ji7',NULL),(922,'7ek8v',NULL),(923,'svjxh',NULL),(924,'qpnps',NULL),(925,'ni1t2',NULL),(926,'wyx39',NULL),(927,'3m0x4',NULL),(928,'i0hvf',NULL),(929,'t7yzl',NULL),(930,'s249l',NULL),(931,'n4f6p',NULL),(932,'mqlt9',NULL),(933,'wy0q8',NULL),(934,'687ez',NULL),(935,'u1lgz',NULL),(936,'b9qhn',NULL),(937,'3cpwm',NULL),(938,'bxmtc',NULL),(939,'583ob',NULL),(940,'s11qr',NULL),(941,'vsnzq',NULL),(942,'s3xvx',NULL),(943,'sadzp',NULL),(944,'lbhg8',NULL),(945,'6gm2r',NULL),(946,'p11op',NULL),(947,'5fevx',NULL),(948,'buhkm',NULL),(949,'fi7i7',NULL),(950,'wq2ut',NULL),(951,'l0c91',NULL),(952,'nbpji',NULL),(953,'9yq27',NULL),(954,'86xlp',NULL),(955,'fuv78',NULL),(956,'xmnm6',NULL),(957,'v46lo',NULL),(958,'xk3vw',NULL),(959,'qaapk',NULL),(960,'32y71',NULL),(961,'jlpan',NULL),(962,'4mxv7',NULL),(963,'9mcjd',NULL),(964,'tjoro',NULL),(965,'8f027',NULL),(966,'bz1h1',NULL),(967,'1u4pe',NULL),(968,'mn200',NULL),(969,'69agt',NULL),(970,'vsg98',NULL),(971,'uir13',NULL),(972,'1zlam',NULL),(973,'6trlg',NULL),(974,'ryffd',NULL),(975,'otndp',NULL),(976,'8juki',NULL),(977,'4n13h',NULL),(978,'9x1hb',NULL),(979,'tsmqy',NULL),(980,'e9clb',NULL),(981,'eg4mr',NULL),(982,'h4cx4',NULL),(983,'qu5sk',NULL),(984,'n149h',NULL),(985,'tw1nh',NULL),(986,'qj0je',NULL),(987,'jwp1d',NULL),(988,'gfmcx',NULL),(989,'tlxgj',NULL),(990,'83jib',NULL),(991,'85w6c',NULL),(992,'qv8m1',NULL),(993,'0lo5t',NULL),(994,'zsrol',NULL),(995,'754vk',NULL),(996,'mkp7x',NULL),(997,'53dcc',NULL),(998,'0ptz4',NULL),(999,'pbw2q',NULL);
/*!40000 ALTER TABLE `yqm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'blcu_site'
--

--
-- Dumping routines for database 'blcu_site'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-22 15:21:44
